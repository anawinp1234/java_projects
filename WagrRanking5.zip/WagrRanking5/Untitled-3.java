









Wager wager =  new Wager("file_name");
// ArrayList<String> ALofLines = wager.getArrLofLines();

// wager.favoritePlayers(ALofLines, "name");
String[] favoritePlayers = {"Connor Willi", "Mahant", "Luke Potter", "Pongsap"};
ArrayList ArrayListofMyFavPlayers = wager.favoritePlayers("Array of name");
// println("here is my fav players");
// println(ArrayListofMyFavPlayers);

for (String eachP : ArrayListofMyFavPlayers) {
    println "DADasd";
    ar
}


ArrayList<String> printMe = favPlayersMeth(favoritePlayers);

for (each line: printMe) {
    println()
}
