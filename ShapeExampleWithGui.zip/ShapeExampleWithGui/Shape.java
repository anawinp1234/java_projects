package classes;

public abstract class Shape {
	
	abstract double area();
	abstract double perimeter();
	
}
