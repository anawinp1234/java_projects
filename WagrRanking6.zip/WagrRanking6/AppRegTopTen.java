
public class AppRegTopTen {
   public static void main(String[] args) {
    WagrFileIO obj = new WagrFileIO("WagrRanking8:7.csv");
    obj.topTen(true);
   }
}
