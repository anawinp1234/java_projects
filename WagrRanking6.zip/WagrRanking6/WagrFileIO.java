import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

public class WagrFileIO{
    
    private ArrayList<String> arrListofLines = new ArrayList<>();
    String fileName = "WagrRanking8:7.csv";

    public WagrFileIO(String fileName) {
        // fileName is file name
        BufferedReader reader;
        String line;
        try {
            reader = new BufferedReader(new FileReader(fileName));
            while ((line = reader.readLine()) != null) {
                String newLine = line.replaceAll("\"", "");
                if (line.contains("Move")) {
                    continue;
                }
                String[] field = newLine.split(",");

                String newStrLine = String.join(" | ", field[0].format("%4s", field[0]), 
                                                       field[1].format("%5s", field[1]), 
                                                       field[3].format("%-26s", field[3]), field[2]);
                arrListofLines.add(newStrLine);
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    
    // public ArrayList<String> getArrListofLines() {
    //     return arrListofLines;
    // }
    
    public void findOnePlyer2(String player) {
        String onePlyrName = player;
        ArrayList<String> nameList = new ArrayList<>();
        for (String line : arrListofLines) {
            String[] field = line.split(" \\| ");
            if (field[2].contains(onePlyrName)) {
                nameList.add(line);
            }
        }
        System.out.println("\nOne particular player:");
        if (nameList.isEmpty()) {
            System.out.println("No one here bro.".toUpperCase());
        } else {
            for (String each : nameList) {
                System.out.println(each);
            }
        }      
    }

    public void favPlayersMeth(String[] favoritePlayers1) {
        String[] favoritePlayersArrNames = favoritePlayers1;
        ArrayList<String> favPlyrsArrList = new ArrayList<>();
        for (String line : arrListofLines) {
            String[] field = line.split(" \\| ");
            for (String eachElem : favoritePlayersArrNames) {
                if (field[2].contains(eachElem)) {
                    favPlyrsArrList.add(eachElem);
                    System.out.println(line);
                }
            }
        }
    }

    public void topTen(boolean regTop10) {

            //these are for regular top 10
            ArrayList<String> topX = new ArrayList<>();
            regTop10 = true;
            for (String line : arrListofLines) {
                String[] field = line.split(" \\| ");
                    //top 10 rank
                    if (regTop10 == true) {
                        int fieldPrimero = Integer.parseInt(field[0].replace(" ", ""));
                    if (fieldPrimero <= 10) {
                            topX.add(line);
                    }
                }
            }
           
    
                if (regTop10 == true) {
                    System.out.println("\nTop 10 Players: ");
                    for (String eachtopXElem : topX) {
                        System.out.println(eachtopXElem);
                    }
                }
    
        }

    public void biggestMovesTopPlyrs(int biggestMoves, int NumOfPlyrs) {
                //these are for big moves 
        int tm = biggestMoves;
        int tr = NumOfPlyrs;
        int n = 0;
        ArrayList<String> trArrList = new ArrayList<>();
        ArrayList<Integer> indexTracker = new ArrayList<>();
        ArrayList<Integer> allMovesList = new ArrayList<>();
        for(int i = 0; i < tr; i++){
            trArrList.add(arrListofLines.get(i));
        }

        for (String eachLine : trArrList) {
            String[] field = eachLine.split(" \\| ");
            int fieldOneInt = Integer.parseInt(field[1].replace(" ", ""));
            int fieldOneIntAbs = Math.abs(fieldOneInt);
            allMovesList.add(fieldOneIntAbs);
        }
        
        for (int i = 1; i <= tm; i++) {
            int maxMoveInt = Collections.max(allMovesList);
            int maxIndexInt = allMovesList.indexOf(maxMoveInt);
            
           
            System.out.println(maxMoveInt + ", " + maxIndexInt);
    
                
                if (maxMoveInt == 0) {
                    System.out.println(maxMoveInt + "--- " + maxIndexInt);
                    maxIndexInt++;
                }
            
            indexTracker.add(maxIndexInt);
            allMovesList.set(maxIndexInt, 0);

        
        }

        System.out.println("\nTop " + tm + " biggest moves out of the top " + tr + " players:");
        for (int eachElem : indexTracker) {
            System.out.println(arrListofLines.get(eachElem));
        }
        
        
        

    }


}


