public class AppFindOnePlayer {
    public static void main(String[] args) {
        WagrFileIO objIO = new WagrFileIO("WagrRanking8:7.csv");
        objIO.findOnePlyr("Summer");
    }
}
