import java.util.ArrayList;
import java.util.Collections;

public class TestSortArrList {
    public static void main(String[] args) {
        ArrayList<Integer> nums = new ArrayList<>();
        nums.add(22);
        nums.add(5);
        nums.add(-25);
        nums.add(32);
        nums.add(52);
        nums.add(62);

        


    }


}
